import cv2
import time


def capture_frames(video_path, output_folder, start_time, interval):
    cap = cv2.VideoCapture(video_path)

    # 设置视频的帧率
    fps = cap.get(cv2.CAP_PROP_FPS)

    # 计算起始帧和间隔帧数
    start_frame = int(start_time * fps)
    interval_frames = int(interval * fps)

    # 设置当前帧
    current_frame = start_frame

    name = video_path.split('\\')[-1].split('.')[0]

    while True:
        # 设置视频的当前帧
        cap.set(cv2.CAP_PROP_POS_FRAMES, current_frame)

        # 读取当前帧
        ret, frame = cap.read()

        # 如果读取失败，说明到达视频结尾，退出循环
        if not ret:
            break

        # 保存当前帧为图片
        output_path = f"{output_folder}/{name}_{current_frame // int(fps)}s.jpg"
        cv2.imencode('.jpg', frame)[1].tofile(output_path)
        print(f"Saved frame {current_frame // int(fps)}s to {output_path}")

        # 更新当前帧
        current_frame += interval_frames

        # 暂停5秒，以便下一次截取
        time.sleep(interval)

    # 释放视频对象
    cap.release()


if __name__ == "__main__":
    video_path = r"D:\B站下载\网友们的神回复276.mp4"  # 替换为你的视频文件路径
    output_folder = "output_frames"  # 替换为保存帧的文件夹路径
    start_time = 3  # 从视频第2秒开始
    interval = 6  # 每隔5秒后换图，一秒切换帧

    # 创建输出文件夹
    import os

    os.makedirs(output_folder, exist_ok=True)

    # 调用函数截取帧
    capture_frames(video_path, output_folder, start_time, interval)
