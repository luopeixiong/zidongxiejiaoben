# qb23Novel

自动爬取铅笔小说收藏夹的小说并生成epub

main.py,character_to_num.py,epub.zip这三个文件必须在同一个目录

修改main.py login函数中param的username,password即可运行测试

本项目仅供开发者学习测试，请在下载后24小时内删除本项目
